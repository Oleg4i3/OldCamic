# SimpleCam

Минималистичная Android-камера с горизонтальным экраном.

**Camera2 API · MediaCodec H.264 · 1-секундный pre-roll · EIS стабилизация**

## Возможности

- Запись 1280×720 @ 30fps, настраиваемый битрейт
- Pre-roll буфер (бесшовный старт записи)
- Цифровая стабилизация (EIS) через crop-region shift
- Ручной фокус / Focus Assist
- Gain, Soft-clip, EV-компенсация
- VU-метр, осциллограф, огибающая, спектр-анализатор FFT-2048
- Zoom-рычаг с экспоненциальной скоростью
- Пауза/возобновление записи

## Требования

| | |
|---|---|
| Min Android | 8.0 (API 26) |
| Target SDK | 34 |
| Build tool | Gradle 8.4 + AGP 8.2.2 |
| JDK | 17 |

## Сборка локально

```bash
# Клонируй репозиторий
git clone https://github.com/<you>/SimpleCam.git
cd SimpleCam

# Собери debug APK
./gradlew assembleDebug

# APK будет по адресу:
# app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

При каждом push в `main`/`master` автоматически запускается сборка.  
APK доступен во вкладке **Actions → последний run → Artifacts → simplecam-debug-N**.

[![Build APK](https://github.com/<you>/SimpleCam/actions/workflows/build.yml/badge.svg)](https://github.com/<you>/SimpleCam/actions/workflows/build.yml)
